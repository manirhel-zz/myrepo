#! /bin/bash

cd ~/Download/fluxday

rails server
