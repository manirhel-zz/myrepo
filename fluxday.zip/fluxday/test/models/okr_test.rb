require 'test_helper'

class OkrTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
