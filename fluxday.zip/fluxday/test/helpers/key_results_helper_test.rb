require 'test_helper'

class KeyResultsHelperTest < ActionView::TestCase
end
