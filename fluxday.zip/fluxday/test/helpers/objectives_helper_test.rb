require 'test_helper'

class ObjectivesHelperTest < ActionView::TestCase
end
