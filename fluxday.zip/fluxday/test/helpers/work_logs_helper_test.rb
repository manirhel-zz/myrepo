require 'test_helper'

class WorkLogsHelperTest < ActionView::TestCase
end
