require 'test_helper'

class OkrsHelperTest < ActionView::TestCase
end
