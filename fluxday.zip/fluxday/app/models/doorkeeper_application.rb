class DoorkeeperApplication < ActiveRecord::Base
end
