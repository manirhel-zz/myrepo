class CreateOauthApplications < ActiveRecord::Migration
  def change
  end
end
