# Be sure to restart your server when you modify this file.

Fluxday::Application.config.session_store :cookie_store, key: '_tracker_session'
