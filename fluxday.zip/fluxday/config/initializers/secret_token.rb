# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Fluxday::Application.config.secret_key_base = 'a1878bcc8a37aa076581e9ef1204c7cecdb572c3492bc36e1ab63bea12c28c8d088505dd3de0296bc6830d20b4cf39b19bf478160c9384534ad9569d0a529203'
